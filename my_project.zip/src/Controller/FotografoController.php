<?php

namespace App\Controller;

use App\Entity\Fotografo;
use App\Entity\Foto;
use App\Form\FotografoType;
use App\Form\FotoType;
use App\Repository\FotografoRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/fotografo')]
final class FotografoController extends AbstractController
{
    #[Route(name: 'app_fotografo_index', methods: ['GET'])]
    public function index(FotografoRepository $fotografoRepository): Response
    {
        return $this->render('fotografo/index.html.twig', [
            'fotografos' => $fotografoRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_fotografo_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $fotografo = new Fotografo();
        $form = $this->createForm(FotografoType::class, $fotografo);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($fotografo);
            $entityManager->flush();

            return $this->redirectToRoute('app_fotografo_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('fotografo/new.html.twig', [
            'fotografo' => $fotografo,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_fotografo_show', methods: ['GET'])]
    public function show(Fotografo $fotografo): Response
    {
        return $this->render('fotografo/show.html.twig', [
            'fotografo' => $fotografo,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_fotografo_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Fotografo $fotografo, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(FotografoType::class, $fotografo);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_fotografo_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('fotografo/edit.html.twig', [
            'fotografo' => $fotografo,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_fotografo_delete', methods: ['POST'])]
    public function delete(Request $request, Fotografo $fotografo, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$fotografo->getId(), $request->request->get('_token'))) {
            $entityManager->remove($fotografo);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_fotografo_index', [], Response::HTTP_SEE_OTHER);
    }

    #[Route('/profile/{id}', name: 'app_fotografo_profile', methods: ['GET', 'POST'])]
    public function profile(
        Request $request,
        Fotografo $fotografo,
        EntityManagerInterface $entityManager,
        SluggerInterface $slugger
    ): Response {
        $foto = new Foto();
        $form = $this->createForm(FotoType::class, $foto);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $uploadedFile = $form['filePath']->getData();

            if ($uploadedFile) {
                $originalFilename = pathinfo($uploadedFile->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $slugger->slug($originalFilename);
                $newFilename = $safeFilename.'-'.uniqid().'.'.$uploadedFile->guessExtension();

                try {
                    $uploadedFile->move(
                        $this->getParameter('uploads_directory'),
                        $newFilename
                    );
                } catch (FileException $e) {
                    $this->addFlash('error', 'Errore durante il caricamento del file');
                    // Puoi anche loggare l'eccezione qui, se vuoi
                }

                $foto->setFilePath($newFilename);
                $foto->setFotografo($fotografo);

                $entityManager->persist($foto);
                $entityManager->flush();

                $this->addFlash('success', 'Foto caricata con successo');

                return $this->redirectToRoute('app_fotografo_profile', ['id' => $fotografo->getId()]);
            }
        }

        return $this->render('fotografo/profile.html.twig', [
            'fotografo' => $fotografo,
            'form' => $form->createView(),
        ]);
    }
}
