<?php

namespace App\Controller;

use App\Entity\Rubrica;
use App\Form\RubricaType;
use App\Repository\RubricaRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/rubrica')]
final class RubricaController extends AbstractController
{
    #[Route(name: 'app_rubrica_index', methods: ['GET'])]
    public function index(RubricaRepository $rubricaRepository): Response
    {
        return $this->render('rubrica/index.html.twig', [
            'rubricas' => $rubricaRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_rubrica_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $rubrica = new Rubrica();
        $form = $this->createForm(RubricaType::class, $rubrica);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($rubrica);
            $entityManager->flush();

            return $this->redirectToRoute('app_rubrica_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('rubrica/new.html.twig', [
            'rubrica' => $rubrica,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_rubrica_show', methods: ['GET'])]
    public function show(Rubrica $rubrica): Response
    {
        return $this->render('rubrica/show.html.twig', [
            'rubrica' => $rubrica,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_rubrica_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Rubrica $rubrica, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(RubricaType::class, $rubrica);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_rubrica_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('rubrica/edit.html.twig', [
            'rubrica' => $rubrica,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_rubrica_delete', methods: ['POST'])]
    public function delete(Request $request, Rubrica $rubrica, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$rubrica->getId(), $request->getPayload()->getString('_token'))) {
            $entityManager->remove($rubrica);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_rubrica_index', [], Response::HTTP_SEE_OTHER);
    }
}
