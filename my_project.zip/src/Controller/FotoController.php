<?php

namespace App\Controller;

use App\Entity\Foto;
use App\Entity\Fotografo;
use App\Form\FotoType;
use App\Repository\FotografoRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\String\Slugger\SluggerInterface;
use Symfony\Component\HttpFoundation\File\Exception\FileException;

class FotoController extends AbstractController
{
    #[Route('/foto/new/{fotografoId}', name: 'app_foto_new', methods: ['GET', 'POST'])]
    public function new(
        int $fotografoId,
        Request $request,
        EntityManagerInterface $em,
        SluggerInterface $slugger,
        FotografoRepository $fotografoRepository
    ): Response
    {
        $fotografo = $fotografoRepository->find($fotografoId);
        if (!$fotografo) {
            throw $this->createNotFoundException('Fotografo non trovato');
        }

        $foto = new Foto();
        $foto->setFotografo($fotografo);

        $form = $this->createForm(FotoType::class, $foto);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $imageFile = $form->get('filePath')->getData();

            if ($imageFile) {
                $originalFilename = pathinfo($imageFile->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $slugger->slug($originalFilename);
                $newFilename = $safeFilename.'-'.uniqid().'.'.$imageFile->guessExtension();

                try {
                    $imageFile->move(
                        $this->getParameter('uploads_directory'),
                        $newFilename
                    );
                } catch (FileException $e) {
                    $this->addFlash('error', 'Errore durante il caricamento dell\'immagine.');
                    return $this->redirectToRoute('app_foto_new', ['fotografoId' => $fotografoId]);
                }

                $foto->setFilePath('uploads/' . $newFilename);
            }

            $em->persist($foto);
            $em->flush();

            $this->addFlash('success', 'Foto caricata con successo!');

            return $this->redirectToRoute('app_fotografo_profile', ['id' => $fotografoId]);
        }

        return $this->render('foto/new.html.twig', [
            'form' => $form->createView(),
            'fotografo' => $fotografo,
        ]);
    }
}
