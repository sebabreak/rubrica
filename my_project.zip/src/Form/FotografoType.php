<?php

namespace App\Form;

use App\Entity\Fotografo;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateType;

class FotografoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('Nome')
            ->add('Cognome')
            ->add('Data_di_nascita', DateType::class, [
                'widget' => 'single_text',
                'html5' => true,
                'label' => 'Data di nascita',
                'required' => false,
            ])
            ->add('Link');
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Fotografo::class,
        ]);
    }
}
