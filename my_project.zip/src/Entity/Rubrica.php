<?php

namespace App\Entity;

use App\Repository\RubricaRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RubricaRepository::class)]
class Rubrica
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Nome = null;

    #[ORM\Column(length: 255)]
    private ?string $Cognome = null;

    #[ORM\Column(length: 255)]
    private ?string $Telefono = null;

    #[ORM\Column(length: 255)]
    private ?string $Mail = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $Commento = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNome(): ?string
    {
        return $this->Nome;
    }

    public function setNome(string $Nome): static
    {
        $this->Nome = $Nome;

        return $this;
    }

    public function getCognome(): ?string
    {
        return $this->Cognome;
    }

    public function setCognome(string $Cognome): static
    {
        $this->Cognome = $Cognome;

        return $this;
    }

    public function getTelefono(): ?string
    {
        return $this->Telefono;
    }

    public function setTelefono(string $Telefono): static
    {
        $this->Telefono = $Telefono;

        return $this;
    }

    public function getMail(): ?string
    {
        return $this->Mail;
    }

    public function setMail(string $Mail): static
    {
        $this->Mail = $Mail;

        return $this;
    }

    public function getCommento(): ?string
    {
        return $this->Commento;
    }

    public function setCommento(?string $Commento): static
    {
        $this->Commento = $Commento;

        return $this;
    }
}
