<?php

namespace App\Entity;

use App\Repository\FotografoRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: FotografoRepository::class)]
class Fotografo
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Nome = null;

    #[ORM\Column(length: 255)]
    private ?string $Cognome = null;

    // Modifica qui: cambia il tipo in date e la proprietà in DateTimeInterface
    #[ORM\Column(type: 'date', nullable: true)]
    private ?\DateTimeInterface $Data_di_nascita = null;

    #[ORM\Column(length: 255)]
    private ?string $Link = null;

    /**
     * @var Collection<int, Foto>
     */
    #[ORM\OneToMany(targetEntity: Foto::class, mappedBy: 'fotografo')]
    private Collection $fotos;

    public function __construct()
    {
        $this->fotos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNome(): ?string
    {
        return $this->Nome;
    }

    public function setNome(string $Nome): static
    {
        $this->Nome = $Nome;

        return $this;
    }

    public function getCognome(): ?string
    {
        return $this->Cognome;
    }

    public function setCognome(string $Cognome): static
    {
        $this->Cognome = $Cognome;

        return $this;
    }

    public function getDataDiNascita(): ?\DateTimeInterface
    {
        return $this->Data_di_nascita;
    }

    public function setDataDiNascita(?\DateTimeInterface $Data_di_nascita): static
    {
        $this->Data_di_nascita = $Data_di_nascita;

        return $this;
    }

    public function getLink(): ?string
    {
        return $this->Link;
    }

    public function setLink(string $Link): static
    {
        $this->Link = $Link;

        return $this;
    }

    /**
     * @return Collection<int, Foto>
     */
    public function getFotos(): Collection
    {
        return $this->fotos;
    }

    public function addFoto(Foto $foto): static
    {
        if (!$this->fotos->contains($foto)) {
            $this->fotos->add($foto);
            $foto->setFotografo($this);
        }

        return $this;
    }

    public function removeFoto(Foto $foto): static
    {
        if ($this->fotos->removeElement($foto)) {
            // set the owning side to null (unless already changed)
            if ($foto->getFotografo() === $this) {
                $foto->setFotografo(null);
            }
        }

        return $this;
    }
}
