<?php

namespace App\Entity;

use App\Repository\ArchivioRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ArchivioRepository::class)]
class Archivio
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Foto = null;

    #[ORM\Column(length: 255)]
    private ?string $Titolo = null;

    #[ORM\Column(length: 255)]
    private ?string $Descrizione = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFoto(): ?string
    {
        return $this->Foto;
    }

    public function setFoto(string $Foto): static
    {
        $this->Foto = $Foto;

        return $this;
    }

    public function getTitolo(): ?string
    {
        return $this->Titolo;
    }

    public function setTitolo(string $Titolo): static
    {
        $this->Titolo = $Titolo;

        return $this;
    }

    public function getDescrizione(): ?string
    {
        return $this->Descrizione;
    }

    public function setDescrizione(string $Descrizione): static
    {
        $this->Descrizione = $Descrizione;

        return $this;
    }
}
