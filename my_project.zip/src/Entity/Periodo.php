<?php

namespace App\Entity;

use App\Repository\PeriodoRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PeriodoRepository::class)]
class Periodo
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $Titolo = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $DataInizio = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $DataFine = null;

    #[ORM\Column]
    private ?bool $isPublic = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $user = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitolo(): ?string
    {
        return $this->Titolo;
    }

    public function setTitolo(string $Titolo): static
    {
        $this->Titolo = $Titolo;

        return $this;
    }

    public function getDataInizio(): ?\DateTimeInterface
    {
        return $this->DataInizio;
    }

    public function setDataInizio(\DateTimeInterface $DataInizio): static
    {
        $this->DataInizio = $DataInizio;

        return $this;
    }

    public function getDataFine(): ?\DateTimeInterface
    {
        return $this->DataFine;
    }

    public function setDataFine(\DateTimeInterface $DataFine): static
    {
        $this->DataFine = $DataFine;

        return $this;
    }

    public function isPublic(): ?bool
    {
        return $this->isPublic;
    }

    public function setIsPublic(bool $isPublic): static
    {
        $this->isPublic = $isPublic;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): static
    {
        $this->user = $user;

        return $this;
    }
}
